// TODO: setup
// TODO: function to get the leaderboard data from the server
// TODO: function to display the leaderboard data on the page
// TODO: function to update the leaderboard data on the page
// TODO: function to get the form from the server, and display it on the json page
